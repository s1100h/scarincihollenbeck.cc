import React from 'react'
import ReactDOM from 'react-dom'
import './just-in-styles.css'
import JustInCarousel from './JustInCarousel'

ReactDOM.render(<JustInCarousel />, document.getElementById('just-in-root'))

