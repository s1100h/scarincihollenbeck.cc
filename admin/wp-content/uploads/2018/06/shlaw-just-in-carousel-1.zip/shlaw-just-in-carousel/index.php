<?php 

// Silence is golden