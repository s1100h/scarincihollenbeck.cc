import { api } from './api-config';

let { token } = localStorage;

if (!token) {
  token = Math.random().toString(36).substr(-8);
}

const headers = {
  Accept: 'application/json',
  Authorization: token,
};

export const getJustInPosts = () =>
  fetch(`${api}just-in/posts`, {headers})
    .then(res => res.json())
    .then(data => data);
