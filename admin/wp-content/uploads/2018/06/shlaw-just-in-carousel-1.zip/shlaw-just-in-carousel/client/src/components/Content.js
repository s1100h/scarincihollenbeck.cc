import React from 'react';
import Moment from 'react-moment';
import 'moment-timezone';
import FaNewspaperO from 'react-icons/lib/fa/newspaper-o';
import FaPlusCircle from 'react-icons/lib/fa/plus-circle';

const Content = (props) => {
  const {title, image, category, link, date, location} = props;
  const publishDate = date;

  return (
    <div className="JustInCarouselContent card">
      <a href={link}>
        <p className="just-in-header">
          <span className="category"><FaNewspaperO />{category}</span>
          <span className="date"><Moment date={publishDate} format="MM/DD/YYYY" /></span>
        </p>
        <div className="just-in-content">
          <h5>{title}</h5>
          <img src={image} alt={title} className="img-thumbnail center-block" />
        </div>
        <hr /><p className="tag"><FaPlusCircle />{location}</p>
      </a>
    </div>
  );
};

export default Content;
