// api urls
const urls = {
  apiStagingLocal: 'http://localhost/shlaw-development/wp-json/',
  stagingSSHSecure: 'https://shlaw.staging.wpengine.com/wp-json/',
  stagingSSHNonSecure: 'http://shlaw.staging.wpengine.com/wp-json/',
  production: 'https://scarincihollenbeck.com/wp-json/',
  hostname: window && window.location && window.location.hostname,
  protocol: window.location.href.split('/')[0],
};

let backendHost;

if (urls.hostname === 'scarincihollenbeck.com') {
  backendHost = urls.production;
} else if (urls.hostname === 'shlaw.staging.wpengine.com' && urls.protocol === 'https:') {
  backendHost = urls.stagingSSH;
} else if (urls.hostname === 'shlaw.staging.wpengine.com' && urls.protocol === 'http:') {
  backendHost = urls.stagingSSHNonSecure;
} else {
  backendHost = urls.apiStagingLocal;
}

export const api = backendHost;
