import React, { Component } from 'react';
import Slider from 'react-slick';
import { FaAngleDoubleRight, FaAngleDoubleLeft } from 'react-icons/lib/fa/';
import Content from './components/Content';
import { getJustInPosts } from './utils/api';

const NextArrow = (props) => {
  const { onClick } = props;
  return <FaAngleDoubleRight className={'just-in-toggles just-in-toggle-right'} onClick={onClick} />;
};

const PrevArrow = (props) => {
  const { onClick } = props;
  return <FaAngleDoubleLeft className={'just-in-toggles just-in-toggle-left'} onClick={onClick} />;
};

class JustInCarousel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: null,
    };
  }
  componentDidMount() {
    getJustInPosts().then(posts => this.setState({posts}));
  }
  render() {
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 4,
      nextArrow: <NextArrow />,
      prevArrow: <PrevArrow />,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1690,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
          },
        },
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2,
          },
        },
        {
          breakpoint: 650,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    return (
      <div className="JustInCarousel container">
        <Slider {...settings}>
          {
              (this.state.posts) ? this.state.posts.map(val => (
                <Content
                  key={val.id}
                  date={val.date}
                  image={val.image}
                  link={val.link}
                  category={val.category}
                  location={val.location}
                  title={val.title}
                />
              )) : ''
          }
        </Slider>
      </div>
    );
  }
}

export default JustInCarousel;
