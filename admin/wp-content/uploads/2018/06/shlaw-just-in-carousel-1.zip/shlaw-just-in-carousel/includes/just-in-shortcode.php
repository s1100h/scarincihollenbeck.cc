<?php

if( !defined('ABSPATH')) { exit; }

function justin_news_shortcode() {
    ?><div id="just-in-root"></div><?php 
}