<?php // Just In Carousel - Loading Custom Scripts

// exit if file is called directly
if( !defined('ABSPATH')) { exit; }
// public stylesheets and scripts
function public_scripts_just_in() {
    wp_enqueue_style('just-in-style', plugin_dir_url(dirname(__FILE__)).'client/build/static/css/main.34918316.css', array(), null, 'screen');
    wp_enqueue_script('just-in-script', plugin_dir_url(dirname(__FILE__)).'client/build/static/js/main.8d54c0ae.js', array(), null, true);
}
// add styles to admin header
add_action('wp_enqueue_scripts', 'public_scripts_just_in' );

 ?>