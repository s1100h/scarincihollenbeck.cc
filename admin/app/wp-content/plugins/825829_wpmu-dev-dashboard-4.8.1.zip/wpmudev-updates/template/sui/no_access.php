<div class="sui-notice sui-notice-error">
	<p><?php esc_html_e( 'You do not have the permission to view this page', 'wpmudev' ); ?></p>
</div>
<?php exit; ?>