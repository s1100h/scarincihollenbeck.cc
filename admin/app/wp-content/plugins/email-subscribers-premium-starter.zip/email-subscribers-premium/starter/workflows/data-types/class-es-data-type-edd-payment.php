<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class ES_Data_Type_EDD_Payment
 */
class ES_Data_Type_EDD_Payment extends ES_Workflow_Data_Type {

	/**
	 * @param $item
	 * @return bool
	 */
	function validate( $item ) {
		return $item instanceof EDD_Payment;
	}


	/**
	 * @param \EDD_Payment $item
	 * @return mixed
	 */
	function compress( $item ) {
		return $item->ID;
	}


	/**
	 * @param $compressed_item
	 * @param $compressed_data_layer
	 * @return mixed
	 */
	function decompress( $compressed_item, $compressed_data_layer ) {
		$id = ES_Clean::id( $compressed_item );

		if ( ! $id ) {
			return false;
		}

		$edd_payment = edd_get_payment( $compressed_item );

		if ( ! $edd_payment || ! $edd_payment instanceof EDD_Payment ) {
			return false;
		}

		return $edd_payment;
	}

	/**
	 * @param \EDD_Payment $item
	 * @return array
	 */
	function get_data( $edd_payment ) {

		$data = array();

		if( $edd_payment instanceof EDD_Payment ) {
			$email = $edd_payment->email;

			if ( ! empty( $email ) ) {

				$user_info = $edd_payment->user_info;

				$first_name = $last_name = '';
				if ( ! empty( $user_info['first_name'] ) ) {
					$first_name = $user_info['first_name'];
				}

				if ( ! empty( $user_info['last_name'] ) ) {
					$last_name = $user_info['last_name'];
				}
				//Prepare data
				$data = array(
					'first_name' => $first_name,
					'last_name'  => $last_name,
					'source'     => 'edd',
					'email'      => $email
				);
			}
		}

		return $data;
	}

}
