<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class ES_Data_Type_CF7_Data
 */
class ES_Data_Type_CF7_Data extends ES_Workflow_Data_Type {

	/**
	 * @param array $item
	 * @return bool
	 */
	function validate( $item ) {
		// Check if we have an array with email field not being empty.
		if( ! is_array( $item ) ||  empty( $item['email'] )  ) {
			return false;
		}
		return true;
	}


	/**
	 * @param $item
	 * @return mixed
	 */
	function compress( $item ) {
		// Return the same $item as submitted contact form aren't saved in DB for later user.
		return $item;
	}

	/**
	 * @param $compressed_item
	 * @param $compressed_data_layer
	 * @return WP_Comment|false
	 */
	function decompress( $compressed_item, $compressed_data_layer ) {
		if ( ! $compressed_item ) {
			return false;
		}

		return $compressed_item;
	}

	/**
	 * @param array
	 * @return array
	 */
	function get_data( $form_saved_data = array() ) {
		
		$data = array();
		if( is_array( $form_saved_data ) && ! empty( $form_saved_data['email'] ) ) {
			$data           = $form_saved_data;
			$data['source'] = 'cf7'; // Add source to cf7 saved data.
		}

		return $data;
	}
}
