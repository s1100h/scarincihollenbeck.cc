<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @class Data_Type_Comment
 */
class ES_Data_Type_Comment extends ES_Workflow_Data_Type {

	/**
	 * @param $item
	 * @return bool
	 */
	function validate( $item ) {
		return $item instanceof WP_Comment;
	}


	/**
	 * @param $item
	 * @return mixed
	 */
	function compress( $item ) {
		return $item->comment_ID;
	}


	/**
	 * @param $compressed_item
	 * @param $compressed_data_layer
	 * @return \WP_Comment|false
	 */
	function decompress( $compressed_item, $compressed_data_layer ) {
		if ( ! $compressed_item ) {
			return false;
		}

		return get_comment( $compressed_item );
	}

	/**
	 * @param WP_Comment $comment
	 * @return array
	 */
	function get_data( $comment ) {
		
		$data  = array();

		if( $comment instanceof WP_Comment ) {
			$email = ! empty( $comment->comment_author_email ) ? $comment->comment_author_email : '';
			// Found email?
			if ( ! empty( $email ) ) {
				$comment_author = ! empty( $comment->comment_author ) ? $comment->comment_author : '';
				$data = array(
					'name'   => $comment_author,
					'email'  => $email,
					'source' => 'comment'
				);
			}
		}

		return $data;
	}
}
