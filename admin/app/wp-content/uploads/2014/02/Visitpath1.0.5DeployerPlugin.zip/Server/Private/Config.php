<?php

	$prot = "http";
	$protocol = (array_key_exists("SERVER_PROTOCOL", $_SERVER) ? $_SERVER["SERVER_PROTOCOL"] : "");
	if(stripos($protocol, "https") !== FALSE)$prot = "https";
	$location = $prot."://".(array_key_exists("HTTP_HOST", $_SERVER) ? $_SERVER["HTTP_HOST"] : "").(array_key_exists("REQUEST_URI", $_SERVER) ? $_SERVER["REQUEST_URI"] : "");
	$index = strpos($location, "?");
	if($index !== FALSE)$location = substr($location, 0, $index);
	$index = strripos($location, "Public/");
	if($index !== FALSE)$location = substr($location, 0, $index);
	$location = trim($location);
	if($location[strlen($location)-1] != "/")$location = $location."/";
	$dir_location = dirname(__FILE__)."/";
	$index = strripos($dir_location, "Private");
	if($index !== FALSE)$dir_location = substr($dir_location, 0, $index);
	$Config_BasePath = $dir_location;
	$Config_BaseURL = $location;
	$Config_DataPath = $Config_BasePath."Data";
	
	$index = strripos($dir_location, "wp-content");
	if($index !== FALSE)
	{
		$Config_DataPath = substr($dir_location, 0, $index)."wp-content/VisitpathDeployerData";
	}
	
	if(!file_exists($Config_DataPath))
	{
		@mkdir($Config_DataPath);
	}
	if(!file_exists($Config_DataPath."/Licenses"))
	{
		@mkdir($Config_DataPath."/Licenses");
	}
	
	$Config_DataPath .= "/";

?>