<?php
	$GlobalPublic = TRUE;
	require_once dirname(__FILE__)."/../Private/Global.php";

	$content = file_get_contents(dirname(__FILE__)."/../Private/Javascript.js");
	$content = str_replace("<%BasePath%>", $BaseURL, $content);
	header("Content-Type: text/javascript");
	header("Cache-Control: max-age=600");
	echo $content;
?>