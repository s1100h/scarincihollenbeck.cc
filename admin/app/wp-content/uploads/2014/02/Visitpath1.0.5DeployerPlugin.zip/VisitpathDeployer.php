<?php
/*
Plugin Name: Visitpath Deployer
Plugin URI: http://visitpath.com/WordPressPluginDownload
Description: After activating the plugin go to `Settings/Visitpath Info` options page to start usign Visitpath.
Version: 1.0.5
Author: Visitpath
Author URI: http://visitpath.com
License: Visitpath proprietary
*/

$VisitpathDeployer_VisitpathDomain = "visitpath.com";
$VisitpathDeployer_Version = "1.0.5";

function VisitpathDeployer_Footer()
{
	echo "<script type=\"text/javascript\" src=\"".plugins_url( 'Server' , __FILE__ )."/Public/Tracker.php\"></script>";
}

function VisitpathDeployer_ModifyMenu()
{
	add_options_page("Visitpath Info", "Visitpath Info", "manage_options", __FILE__, "VisitpathDeployer_OptionsPage");
}

function VisitpathDeployer_OptionsPage()
{
	global $VisitpathDeployer_VisitpathDomain;
	global $VisitpathDeployer_Version;
	$ResttingPassword = FALSE;
	if(array_key_exists("VisitpathDeployerResetPassword", $_POST))
	{
		if($_POST["VisitpathDeployerResetPassword"] == "Reset")
		{
			$path = plugin_dir_path(__FILE__)."/Server/Data";
			$files = scandir($path);
			for($i = 0; $i < count($files); $i++)
			{
				$file = $files[$i];
				if(strpos($file, ".pass") !== FALSE)
				{
					unlink($path."/".$file);
				}
			}
			$ResttingPassword = TRUE;
		}
	}
	?>
	<div class="wrap">
		<h2>Visitpath information page</h2>
		<p>You are running the Visitpath Deployer Plugin version <?php echo $VisitpathDeployer_Version ?>.</p>
		<p>For more information about Visitpath please refer to <a href="http://<?php echo $VisitpathDeployer_VisitpathDomain ?>">http://<?php echo $VisitpathDeployer_VisitpathDomain ?></a>.</p>
		<p>To use Visitpath you need to install the Visitpath client software on your computer and connect to your webstie with it. The client software is a program that you can install on one or more computers from which you plan to monitor your web site. It provides an user interface that allows you to monitor in real time all visitors on your web site and initiate visual monitoring seasion with each of them. It also gives you access to all other features of the Visitpath software. For more information on how to use the client software please refer to the <a href="<%BaseUrl%>HowToUse" title="Describes how to use Visitpath to optimize your own website.">How to use page</a>.</p>
		<h3>Client software system requirements</h3>
		<p>Your computer must meet the following requirements to run Visitpath.</p>
		<ul>
			<li>- It must run Microsfot Windows XP or later operating system.</li>
		</ul>
		<h3>Installation instructions</h3>
		<p>In order to install the Visitpath client software please follow the steps described below:</p>
		<ul>
			<li>- Download the latest version of the Visitpath client from this link: <a href="http://<?php echo $VisitpathDeployer_VisitpathDomain ?>/SoftwareDownload?Version=<?php echo $VisitpathDeployer_Version ?>" target="_blank">Visitpath<?php echo $VisitpathDeployer_Version ?>Setup.zip</a>. Alternativly you can browse through all available versions on the <a href="http://<?php echo $VisitpathDeployer_VisitpathDomain ?>/HowToInstallDownloads" title="Downloads for the client and server side components">Downloads page</a>.</li>
			<li>- Extract the content of the downloaded achive. The archive contains only one executable file.</li>
			<li>- Run the extracted executable file by double-clicking on it.</li>
			<li>- The installation process will start. On the first screen choose a language for the installation process and proceed to the next screen by clicking the `Next` button.</li>
			<li>- On the next screen select the `New installation` radio button and choose name for the installation. This name will be used as software name in all shortcut names, in Add/Remove programs and other places where the Visitpath installation is refered.</li>
			<li>- Click on the `Install` button.</li>
			<li>- Follow the instruction through the rest of the setup process.</li>
		</ul>
		<h3>Connecting to your website</h3>
		<p>To connect to yout website please follow the steps described below.</p>
		<ul>
			<li>- To connect to your website start the Visitpath client software that you installed on your computer.</li>
			<li>- In the `URL to your Visitpath installation` copy the address printed below these instructions.</li>
			<li>- In the `Password` field tyoe in your Visitpath password. By default the password is empty. You can change the password by clicking on the `Password` button in the Visitpath client software. If you have forgotten your should reset it using the instructions in the `Forgotten password` section on this page.</li>
		</ul>
		<p>URL to your Visitpath installation: <strong><?php echo plugins_url( 'Server' , __FILE__ ) ?></strong></p>
		<h3>Forgotten password</h3>
		<p>If you have forgotten your Visitpath password please hit the `Reset password` button below to reset it to empty password. After you do that you will be able to connect using empty password. Then you can set a new password by clicking on the `Password` button in the Visitpath client software.</p>
		<form method="post">
			<input type="hidden" id="VisitpathDeployerResetPassword" name="VisitpathDeployerResetPassword" value="Reset" />
			<?php submit_button('Reset password'); ?>
		</form>
		<?php if($ResttingPassword){?>
		<p><strong>Your Visitpath password has been successfully change to empty password. Log in and change it to something more secure.</strong></p>
		<?php } ?>
	</div>
	<?php
}

add_action("admin_menu", "VisitpathDeployer_ModifyMenu");

add_action("wp_footer", "VisitpathDeployer_Footer", 100);
wp_register_script( $handle, $src, $deps, $ver, $in_footer );

?>